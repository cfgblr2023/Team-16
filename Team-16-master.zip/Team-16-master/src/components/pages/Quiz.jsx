import React from 'react'
import { Link } from 'react-router-dom'

import '../../App.css'

export default function Quiz() {
    return (
        <div>
            <form>
                <p>Q1. Select the hanging wire in the following </p><br/>
                <p>Q2. Garbage Waste</p><br/>
                <p>Q3. Vendor parking at restricted area</p><br/>
                <p>Q4. Pit in the footpath</p><br/>
                <p>Q5. Line path damage in the following</p><br/>
            </form>
        </div>
    )
}
